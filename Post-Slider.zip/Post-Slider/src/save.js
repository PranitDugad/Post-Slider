// src/save.js

const Save = () => {
    return null;
};

export default Save;